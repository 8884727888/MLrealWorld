# This repo is for my upcoming session on continous model deployment
Will update details post the session - In the session

UPdate to demo in AIEngineering channel
